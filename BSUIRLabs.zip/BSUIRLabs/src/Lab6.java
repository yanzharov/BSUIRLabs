import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

public class Lab6 extends Application {

    private static XYChart.Series series1 = new XYChart.Series();

    @Override public void start(Stage stage) {
        double minX1 = getMinimumX(2, 11, 0.01, true);
        double minX2 = getMinimumX(2, 11, 0.001, false);
        double minX3 = getMinimumX(2, 11, 0.0001, false);
        double minX4 = getMinimumX(2, 11, 0.00001, false);

        System.out.println("MinimumX = " + minX4);
        System.out.println("MinimumY = " + customFunction(minX4));



        stage.setTitle("Lagranz Chart");
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        final LineChart<Number,Number> lineChart = new LineChart<>(xAxis,yAxis);

        lineChart.setTitle("Get function minimum");

        Scene scene  = new Scene(lineChart,800,600);
        lineChart.getData().addAll(series1);

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    private static double customFunction(double x) {
        return Math.log(x) - 5 * Math.cos(x) * Math.cos(x);
    }


    private static double getMinimumX(double start, double end, double step, boolean showPlot)
    {
        int counter = 0;
        double xMin = start;
        double fMin = customFunction(start);
        while(start < end)
        {
            if (showPlot) series1.getData().add(new XYChart.Data(start, customFunction(start)));
            if(customFunction(start) < fMin)
            {
                xMin = start;
                fMin = customFunction(start);
            }
            start +=step;
            counter++;
        }
        System.out.println("Iteration number with e = " + step + " equals to " + counter);
        return xMin;
    }
}
