import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

public class Lab3 extends Application  {
    static final int a = 1;
    static final int b = 8;
    static final int m = 4;
    static final int n = 4;

    @Override public void start(Stage stage) {
        double[] xs = getXS();
        System.out.print("Vector X: ");
        for (double xi : xs) {
            System.out.print(xi + " ");
        }
        System.out.println();
        double[] ys = getYS(xs);
        System.out.print("Vector Y: ");
        for (double yi : ys) {
            System.out.print(yi + " ");
        }
        System.out.println();
        System.out.print("Test X points: ");
        double[] testXPoints = getTestPoints();
        for (double xt : testXPoints) {
            System.out.print(xt + " ");
        }
        System.out.println();
        System.out.print("Test Y points: ");
        double[] testYPoints = getYS(testXPoints);
        for (double yt : testYPoints) {
            System.out.print(yt + " ");
        }
        System.out.println();
        System.out.print("Lagranz Y points: ");
        double[] lagranzPoints = new double[testXPoints.length];
        for (int i=0; i<testXPoints.length; i++) {
            double res = lagranz(xs, ys,testXPoints[i]);
            System.out.print(res + " ");
            lagranzPoints[i] = res;
        }


        stage.setTitle("Lagranz Chart");
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        final LineChart<Number,Number> lineChart = new LineChart<>(xAxis,yAxis);

        lineChart.setTitle("Lagranz approximation");

/*        XYChart.Series series1 = new XYChart.Series();
        series1.setName("Point table function");
        for (int i=0; i<xs.length; i++) {
            series1.getData().add(new XYChart.Data(xs[i], ys[i]));
        }*/

        XYChart.Series series2 = new XYChart.Series();
        series2.setName("Basic function");
        for (int i=0; i<testXPoints.length; i++) {
            series2.getData().add(new XYChart.Data(testXPoints[i], testYPoints[i]));
        }

        XYChart.Series series3 = new XYChart.Series();
        series3.setName("Lagranz approximation");
        for (int i=0; i<lagranzPoints.length; i++) {
            series3.getData().add(new XYChart.Data(testXPoints[i], lagranzPoints[i]));
        }

        Scene scene  = new Scene(lineChart,800,600);
        lineChart.getData().addAll(series2, series3);

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }


    private static double[] getXS() {
        double[] xs = new double[m];
        for (int i = 1; i <= m; i++) {
            xs[i - 1] = a + (i - 1) * (b - a) / (m - 1);
        }
        return xs;
    }

    private static double[] getYS(double[] xs) {
        double[] ys = new double[xs.length];
        for (int i = 0; i < xs.length; i++) {
            ys[i] = Math.log(xs[i]) - 5 * Math.cos(xs[i]);
        }
        return ys;
    }

    private static double lagranz(double X[], double Y[], double t) {
        double z, p1, p2;
        z = 0;
        for (int j = 0; j < n; j++) {
            p1 = 1;
            p2 = 1;
            for (int i = 0; i < n; i++) {
                if (i == j) {
                    p1 = p1 * 1;
                    p2 = p2 * 1;
                } else {
                    p1 = p1 * (t - X[i]);
                    p2 = p2 * (X[j] - X[i]);
                }
            }
            z = z + Y[j] * p1 / p2;
        }
        return z;
    }

    private static double[] getTestPoints() {
        double[] testPoints = new double[21];
        for (int i=1; i<=21; i++) {
            testPoints[i-1] = a + (i-1)*(b-a)/20;
        }
        return testPoints;
    }
}
