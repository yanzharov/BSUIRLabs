import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

public class Lab5 extends Application {
    XYChart.Series series1 = new XYChart.Series();

    @Override public void start(Stage stage) {
        for (double i = 1; i < 8; i+=0.01) {
            series1.getData().add(new XYChart.Data(i, f(i)));
        }
        System.out.println("X1 = " + Secant(1,8,0.0001));
        System.out.print(" Error = " + Math.abs(f(1.4908428440293133)));
        System.out.println();
        System.out.println("X2 = " + Secant(3,6,0.0001));
        System.out.print(" Error = " + Math.abs(f(5.041873756745943)));
        System.out.println();
        System.out.println("X3 = " + Secant(6,8,0.0001));
        System.out.print(" Error = " + Math.abs(f(7.440936817737424)));

        stage.setTitle("Horda Chart");
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        final LineChart<Number,Number> lineChart = new LineChart<>(xAxis,yAxis);

        lineChart.setTitle("Horda method");

        Scene scene  = new Scene(lineChart,800,600);
        lineChart.getData().addAll(series1);

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }


    private static double f(double x) {
        return Math.log(x) - 5 * Math.cos(x);
    }

    public static double Secant(double xa, double xb, double epsilon)
    {
        double xlast;
        double x = 0;
        int iter = 0;
        do
        {
            xlast = x;
            x = xb - f(xb) * (xb - xa) / (f(xb) - f(xa));

            if (f(x) * f(xa) > 0)
            {
                xa = x;
            }
            else
            {
                xb = x;
            }

            iter++;
        }
        while (Math.abs(x - xlast) > epsilon || (xb - xa) <= epsilon || iter == 1000);

        return x;
    }
}
